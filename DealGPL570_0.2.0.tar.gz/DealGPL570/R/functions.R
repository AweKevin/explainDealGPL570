#' Dealing GPL570 (Affymetrix Human Genome U133 Plus 2.0 Array) RAW.tar file using the robust multi-array average expression measure
#'
#' @param file a file name specified by either a variable of mode character, or a double-quoted string, which is of 'GSE*_RAW.tar' which is of platform GPL570.
#' @return 3 types of txt.
#' @import dplyr
#' @import affy
#' @import stringr
#' @import tibble
#' @importFrom GEOquery gunzip
#' @importFrom stats aggregate median
#' @importFrom utils untar write.table
#' @export
#' @examples
#'
#' # You can put your own `GSE*_RAW.tar` under the working directory
#' # Next step would run for about 30s, so you can try it yourself
#' # You can put your own `GSE*_RAW.tar` under the working directory
#' file <- system.file("extdata", "GSE104683_RAW.tar", package = "DealGPL570")
#' file
#' # DealGPL570(file = file)
DealGPL570 <- function(file) {
  exdir <- file %>% str_extract("GSE\\d+")
  untar(file, exdir = exdir)
  gz <- list.files(path = exdir, pattern = "*.gz$")
  sapply(paste(exdir, gz, sep = "/"), gunzip)
  cels <- list.celfiles(exdir, full.names = T)
  l <- do.call(c, lapply(cels, FUN = function(x) {
    ReadAffy(filenames = x) %>% BiocGenerics::annotation()
  }))
  cels <- cels[which(l == "hgu133plus2")]
  affy_data <- ReadAffy(filenames = cels)
  unlink(exdir, recursive = T)
  affy.rma <- rma(affy_data)
  exprSet <- exprs(affy.rma) %>% as.data.frame() %>% rownames_to_column(var = "probe_id")
  write.table(exprSet, file = paste0(exdir, ".rma.txt"), row.names = F,
              sep = "\t", quote = F)
  exprSet$probe_id <- as.character(exprSet$probe_id)
  exprSet.both <- probe2symbol_df %>% inner_join(exprSet) %>%
    distinct()
  write.table(exprSet.both, file = paste0(exdir, "_gene.both.txt"),
              row.names = F, sep = "\t", quote = F)
  exprSet2 <- exprSet %>% inner_join(probe2symbol_df, by = "probe_id") %>%
    dplyr::select(-"probe_id") %>% dplyr::select("symbol", everything())
  exprSet3 <- aggregate(exprSet2[, -1], by = list(exprSet2$symbol),
                       FUN = median) %>% as.data.frame()
  names.col <- c("symbol", names(exprSet)[-1])
  names(exprSet3) <- names.col
  write.table(exprSet3, file = paste0(exdir, "_gene.txt"),
              row.names = F, sep = "\t", quote = F)
}
